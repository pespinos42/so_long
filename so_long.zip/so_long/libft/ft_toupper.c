/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_toupper.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/22 11:27:07 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 12:32:43 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_toupper(int c)
{
	if (c >= 97 && c <= 122)
		c -= 32;
	return (c);
}

/*int main()
{
	int	l = 97;
	printf("MIA %c -> %c\n", l, ft_toupper(l));
	int l2 = 97;
	printf("OFICIAL %c -> %c\n", l2, toupper(l2));
	return 0;
}*/
