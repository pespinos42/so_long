/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalpha.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: atlantico <atlantico@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:57:50 by pespinos          #+#    #+#             */
/*   Updated: 2022/09/25 22:25:27 by atlantico        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include <ctype.h>
#include "libft.h"

int	ft_isalpha(int c)
{
	return ((c >= 65 && c <= 90) || (c >= 97 && c <= 122));
}

/*int main()
{
	int	l;

	l = 70;
	printf("MIA %i es %i\n", l, ft_isalpha(l));	
	printf("OFICIAL %i es %i\n", l, isalpha(l));
	l = 41;
	printf("MIA %i es %i\n", l, ft_isalpha(l));
	printf("OFICIAL %i es %i\n", l, isalpha(l));

	return (0);
}*/
