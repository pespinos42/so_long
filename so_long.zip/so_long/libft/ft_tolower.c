/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_tolower.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/22 11:39:16 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 12:32:40 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_tolower(int c)
{
	if (c >= 65 && c <= 90)
		c += 32;
	return (c);
}

/*int main()
{
	int	l = 64;
	printf("MIA %c -> %c\n", l, ft_tolower(l));
	int	l2 = 64;
	printf("OFICIAL %c -> %c\n", l2, tolower(l2));
	return (0);
}*/
