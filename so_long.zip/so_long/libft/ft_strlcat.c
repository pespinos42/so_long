/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:53:32 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 12:31:43 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t	dst_len;
	size_t	src_len;
	size_t	p;

	dst_len = ft_strlen((const char *)dst);
	src_len = ft_strlen(src);
	p = 0;
	if (dstsize == 0 || dst_len >= dstsize)
		return (dstsize + src_len);
	while (*dst)
		dst++;
	while (src[p] && (p < (dstsize - dst_len - 1)))
	{
		*(dst + p) = src[p];
		p++;
	}
	dst[p] = '\0';
	return (dst_len + src_len);
}

/*int main()
{
	char str1[] = "HOLA";
	char str2[] = " MUNDO";

	printf("%zu %s\n", ft_strlcat(str1, str2, 11), str1);
	return 0;
}*/
