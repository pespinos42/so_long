/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/21 15:27:01 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 12:24:05 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dst, const void *src, size_t len)
{
	unsigned char	*dst2;
	unsigned char	*src2;
	size_t			p;

	dst2 = (unsigned char *) dst;
	src2 = (unsigned char *) src;
	p = 0;
	if (dst2 == NULL && src2 == NULL)
		return (0);
	while (p < len)
	{
		if (dst < src)
			dst2[p] = src2[p];
		else
			dst2[len - p - 1] = src2[len - p - 1];
		p++;
	}
	return (dst);
}

/*int main()
{
	char dest[] = "oldstring";
	const char src[] = "newstring";

	printf("Before memmove dest = %s, src = %s\n", dest, src);
	memmove(dest, src, 9);
	printf("After memmove dest = %s, src = %s\n", dest, src);

	char dest2[] = "oldstring"; 
	const char src2[] = "newstring";

	printf("MIA Befor memmove dest = %s, src = %s\n", dest2, src2);
	ft_memmove(dest2, src2, 9);
	printf("After memmove dest = %s, src = %s\n", dest, src);
	
	return (0);
}*/
