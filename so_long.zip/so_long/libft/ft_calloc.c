/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/22 18:38:37 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 13:15:00 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <unistd.h>
#include "libft.h"

void	*ft_calloc(size_t count, size_t size)
{
	int		*array;
	size_t	p;

	p = 0;
	array = (int *) malloc(count * size);
	if (array)
	{
		ft_bzero(array, count * size);
		return (array);
	}
	else
	{
		free(array);
		return (NULL);
	}
}

/*void ft_print_array(int *array, int positions)
{
	int     p;
	char	letter;
	
	p = 0;
	letter = 0;
	while (p < positions)
	{
	    letter = array[p] + 48;
		write(1, &letter, 1);
		p++;
	}
}

int main()
{
	int *n;

	n = ft_calloc(10, 40);
	ft_print_array(n, 10);
	return 0;
}*/
