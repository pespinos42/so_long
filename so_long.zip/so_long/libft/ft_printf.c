/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/10 12:22:59 by pespinos          #+#    #+#             */
/*   Updated: 2022/12/20 15:55:12 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_control(char option, va_list args, int *count)
{
	if (option == 'c')
		ft_print_char(va_arg(args, int), count);
	else if (option == 's')
		ft_print_str(va_arg(args, char *), count);
	else if (option == 'p')
		ft_print_pointer(va_arg(args, unsigned long long), count);
	else if (option == 'd' || option == 'i')
		ft_printnbr(va_arg(args, int), count);
	else if (option == 'u')
		ft_printunsigned(va_arg(args, unsigned int), count);
	else if (option == 'x')
		ft_print_hexa(va_arg(args, unsigned int), 0, count, 0);
	else if (option == 'X')
		ft_print_hexa(va_arg(args, unsigned int), 1, count, 0);
	else if (option == '%')
		ft_print_char('%', count);
}

int	ft_printf(char const *str, ...)
{
	va_list	args;
	int		count;
	int		p;

	p = 0;
	count = 0;
	va_start(args, str);
	while (*str)
	{
		while (*str != '%' && *str)
		{
			ft_print_char(*str, &count);
			str++;
		}
		if (*str == '%')
		{
			str++;
			ft_control(*str, args, &count);
			str++;
		}
	}
	va_end(args);
	return (count);
}
