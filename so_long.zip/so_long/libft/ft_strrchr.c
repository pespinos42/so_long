/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/22 16:41:57 by pespinos          #+#    #+#             */
/*   Updated: 2022/12/20 16:17:40 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_last_occurrence(char *str, char c)
{
	int	p;
	int	last;

	p = 0;
	last = -1;
	while (str[p])
	{
		if (str[p] == c)
			last = p;
		p++;
	}
	if (c == '\0')
		last = p;
	return (last);
}

char	*ft_strrchr(const char *s, int c)
{
	int	n;

	n = ft_last_occurrence((char *)s, c);
	if (n != -1)
		return ((char *)&s[n]);
	return (NULL);
}

/*int main()
{
	char str[] = "hola caracolas";
	char c = 'l';

	printf("%s - %c -> %s\n", str, c, ft_strrchr(str, c));
	return 0;
}*/
