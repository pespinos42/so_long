/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_hexa.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/10 18:18:14 by pespinos          #+#    #+#             */
/*   Updated: 2022/12/20 15:54:51 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_print_hexa(unsigned long long n, int ca, int *count, int loop)
{
	if (n == 0 && loop == 0)
		ft_print_char('0', count);
	if (n < 0)
	{
		n = 4294967296 + n;
	}
	if (n > 0)
	{
		loop++;
		ft_print_hexa(n / 16, ca, count, loop);
		if ((n % 16) < 10)
			ft_print_char((n % 16) + 48, count);
		else if (ca == 1)
			ft_print_char((n % 16) + 55, count);
		else if (ca == 0)
			ft_print_char((n % 16) + 87, count);
	}
}

void	ft_print_pointer(unsigned long long n, int *count)
{
	ft_print_str("0x", count);
	if (n == 0)
		ft_print_char('0', count);
	else
		ft_print_hexa(n, 0, count, 0);
}
