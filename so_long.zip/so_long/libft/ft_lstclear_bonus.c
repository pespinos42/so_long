/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear_bonus.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/01 12:13:57 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/01 16:28:26 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstclear(t_list **lst, void (*del)(void *))
{
	t_list	*pointer;

	pointer = NULL;
	if (lst)
	{
		while (*lst)
		{
			pointer = (*lst)->next;
			ft_lstdelone(*lst, del);
			*lst = pointer;
		}
	}
	free(pointer);
}
