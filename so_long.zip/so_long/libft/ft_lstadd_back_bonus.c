/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstadd_back_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/01 12:09:45 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/01 16:37:42 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstadd_back(t_list **lst, t_list *new)
{
	t_list	*pointer;

	pointer = *lst;
	if (new)
	{
		if (!*lst)
			*lst = new;
		else
		{
			pointer = ft_lstlast(*lst);
			pointer->next = new;
		}
	}
}
