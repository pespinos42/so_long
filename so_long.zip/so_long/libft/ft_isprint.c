/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isprint.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:59:38 by pespinos          #+#    #+#             */
/*   Updated: 2022/09/25 13:09:27 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include <ctype.h>
#include "libft.h"

int	ft_isprint(int c)
{
	return (c >= 32 && c <= 126);
}

/*int main()
{
	int	l;

	l = 20;
	printf("MIA %i es %i\n", l, ft_isprint(l));
	printf("OFICIAL %i es %i\n", l, isprint(l));
	l = 126;
	printf("MIA %i es %i\n", l, ft_isprint(l));
	printf("OFICIAL %i es %i\n", l, isprint(l));
	return (0);
}*/
