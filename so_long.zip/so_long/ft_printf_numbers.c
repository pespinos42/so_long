/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_numbers.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/10 18:17:24 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/09 12:57:50 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	ft_printunsigned(long int n, int *count)
{
	if (n < 0)
		n = 4294967296 + n;
	if (n > 9)
		ft_printunsigned(n / 10, count);
	ft_print_char((n % 10) + 48, count);
}

void	ft_printnbr(int n, int *count)
{
	if (n == -2147483648)
		ft_print_str("-2147483648", count);
	else if (n < 0)
	{
		ft_print_char('-', count);
		n *= -1;
	}
	if (n >= 0)
	{
		if (n > 9)
			ft_printnbr(n / 10, count);
		ft_print_char((n % 10) + 48, count);
	}
}
