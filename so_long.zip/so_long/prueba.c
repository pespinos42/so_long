/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prueba.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/08 12:35:48 by pespinos          #+#    #+#             */
/*   Updated: 2022/12/08 12:40:02 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

typedef struct s_prueba
{
    int position;
}   t_prueba;

void    ft_incrementar_tres(t_prueba *p)
{
    p->position += 1;
}

void    ft_incrementar_dos(t_prueba *p)
{
    p->position += 1;
    ft_incrementar_tres(p);
}

void    ft_incrementar_uno(t_prueba *p)
{
    p->position += 1;
    ft_incrementar_dos(p);
}

int main()
{
    t_prueba prueba;

    prueba.position = 0;
    ft_incrementar_uno(&prueba);
    printf("MAIN -> %i\n", prueba.position);
    return (0);
}