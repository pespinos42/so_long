/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_str.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/10 18:17:50 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/09 12:57:55 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	ft_print_char(char c, int *count)
{
	write(1, &c, 1);
	*count += 1;
}

void	ft_put_str(char *str, int *count)
{
	while (*str)
	{
		ft_print_char(*str, count);
		str++;
	}
}

void	ft_print_str(char *str, int *count)
{
	if (str == NULL)
		ft_put_str("(null)", count);
	else
	{
		while (*str)
		{
			ft_print_char(*str, count);
			str++;
		}
	}
}
