/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   graficos2_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/09 18:35:11 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/11 10:34:15 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

void	ft_draw_exits(t_all *d, int r, int c)
{
	ft_count_positions(d, &d->n_c, 'C');
	if (d->n_c)
		mlx_image_to_window(d->mlx, d->i_c_ex, 32 * c, 32 * r);
	else
	{
		if (d->t_m % 2 == 0)
			mlx_image_to_window(d->mlx, d->i_c_ex, 32 * c, 32 * r);
		else
			mlx_image_to_window(d->mlx, d->i_o_ex, 32 * c, 32 * r);
	}
}

void	ft_draw_map_conditions(t_all *d, int r, int c)
{
	if (d->con[r][c] == '1')
		mlx_image_to_window(d->mlx, d->i_wa, 32 * c, 32 * r);
	else if (d->con[r][c] == '0')
		mlx_image_to_window(d->mlx, d->i_es, 32 * c, 32 * r);
	else if (d->con[r][c] == 'P')
		mlx_image_to_window(d->mlx, d->i_pl, 32 * c, 32 * r);
	else if (d->con[r][c] == 'E')
		ft_draw_exits(d, r, c);
	else if (d->con[r][c] == 'C')
		mlx_image_to_window(d->mlx, d->i_co, 32 * c, 32 * r);
	else if (d->con[r][c] == 'X')
		mlx_image_to_window(d->mlx, d->i_en, 32 * c, 32 * r);
}

void	ft_draw_map(t_all *d)
{
	int	r;
	int	c;

	r = 0;
	c = 0;
	while (r < d->rs)
	{
		c = 0;
		while (c < d->cs)
		{
			ft_draw_map_conditions(d, r, c);
			c++;
		}
		r++;
	}
}

void	ft_initial_counter(t_all *d)
{
	int	c;

	c = 0;
	while (c < d->w)
	{
		mlx_image_to_window(d->mlx, d->i_n0, 32 * c, 32 * d->rs);
		c++;
	}
}

void	ft_check_counter(t_all *d, char *counter, int i, int p)
{
	if (counter[i] == '0')
		mlx_image_to_window(d->mlx, d->i_n0, p, d->rs * 32);
	else if (counter[i] == '1')
		mlx_image_to_window(d->mlx, d->i_n1, p, d->rs * 32);
	else if (counter[i] == '2')
		mlx_image_to_window(d->mlx, d->i_n2, p, d->rs * 32);
	else if (counter[i] == '3')
		mlx_image_to_window(d->mlx, d->i_n3, p, d->rs * 32);
	else if (counter[i] == '4')
		mlx_image_to_window(d->mlx, d->i_n4, p, d->rs * 32);
	else if (counter[i] == '5')
		mlx_image_to_window(d->mlx, d->i_n5, p, d->rs * 32);
	else if (counter[i] == '6')
		mlx_image_to_window(d->mlx, d->i_n6, p, d->rs * 32);
	else if (counter[i] == '7')
		mlx_image_to_window(d->mlx, d->i_n7, p, d->rs * 32);
	else if (counter[i] == '8')
		mlx_image_to_window(d->mlx, d->i_n8, p, d->rs * 32);
	else if (counter[i] == '9')
		mlx_image_to_window(d->mlx, d->i_n9, p, d->rs * 32);
}
