/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   graficos3_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/09 18:35:59 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/11 12:06:48 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

void	ft_counter(t_all *d)
{
	char	*counter;
	int		len;
	int		i;
	int		p;

	i = 0;
	p = 0;
	counter = ft_itoa(d->t_m);
	len = ft_strlen(counter);
	i = len - 1;
	while (i >= 0)
	{
		p = d->w - (32 * (len - i));
		ft_check_counter(d, counter, i, p);
		i--;
	}
	free (counter);
}

void	ft_op_positions(t_all *d)
{
	if (d->move == 'W')
	{
		d->o_r = d->p_r - 1;
		d->o_c = d->p_c;
	}
	else if (d->move == 'A')
	{
		d->o_r = d->p_r;
		d->o_c = d->p_c - 1;
	}
	else if (d->move == 'S')
	{
		d->o_r = d->p_r + 1;
		d->o_c = d->p_c;
	}
	else if (d->move == 'D')
	{
		d->o_r = d->p_r;
		d->o_c = d->p_c + 1;
	}
}
