/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   graficos1_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/01/09 18:28:48 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/11 10:34:11 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

void	ft_initialize_counter2(t_all *d)
{
	d->i_n0 = mlx_texture_to_image(d->mlx, d->t_n0);
	d->i_n1 = mlx_texture_to_image(d->mlx, d->t_n1);
	d->i_n2 = mlx_texture_to_image(d->mlx, d->t_n2);
	d->i_n3 = mlx_texture_to_image(d->mlx, d->t_n3);
	d->i_n4 = mlx_texture_to_image(d->mlx, d->t_n4);
	d->i_n5 = mlx_texture_to_image(d->mlx, d->t_n5);
	d->i_n6 = mlx_texture_to_image(d->mlx, d->t_n6);
	d->i_n7 = mlx_texture_to_image(d->mlx, d->t_n7);
	d->i_n8 = mlx_texture_to_image(d->mlx, d->t_n8);
	d->i_n9 = mlx_texture_to_image(d->mlx, d->t_n9);
	if (!d->i_n0 || !d->i_n1 || !d->i_n2 || !d->i_n3 || !d->i_n4)
		exit(EXIT_FAILURE);
	if (!d->i_n5 || !d->i_n6 || !d->i_n7 || !d->i_n8 || !d->i_n9)
		exit(EXIT_FAILURE);
	ft_initial_counter(d);
}

void	ft_initialize_counter1(t_all *d)
{
	d->t_n0 = mlx_load_png("./sprites/n0.png");
	d->t_n1 = mlx_load_png("./sprites/n1.png");
	d->t_n2 = mlx_load_png("./sprites/n2.png");
	d->t_n3 = mlx_load_png("./sprites/n3.png");
	d->t_n4 = mlx_load_png("./sprites/n4.png");
	d->t_n5 = mlx_load_png("./sprites/n5.png");
	d->t_n6 = mlx_load_png("./sprites/n6.png");
	d->t_n7 = mlx_load_png("./sprites/n7.png");
	d->t_n8 = mlx_load_png("./sprites/n8.png");
	d->t_n9 = mlx_load_png("./sprites/n9.png");
	if (!d->t_n0 || !d->t_n1 || !d->t_n2 || !d->t_n3 || !d->t_n4)
		exit(EXIT_FAILURE);
	if (!d->t_n5 || !d->t_n6 || !d->t_n7 || !d->t_n8 || !d->t_n9)
		exit(EXIT_FAILURE);
	ft_initialize_counter2(d);
}

void	ft_initialize_textures(t_all *d)
{
	d->t_co = mlx_load_png("./sprites/collectable.png");
	d->t_es = mlx_load_png("./sprites/empty_space.png");
	d->t_c_ex = mlx_load_png("./sprites/closed_door.png");
	d->t_o_ex = mlx_load_png("./sprites/open_door.png");
	d->t_pl = mlx_load_png("./sprites/player.png");
	d->t_wa = mlx_load_png("./sprites/wall.png");
	d->t_en = mlx_load_png("./sprites/enemy.png");
	if (!d->t_co || !d->t_es || !d->t_c_ex || !d->t_o_ex)
		exit (EXIT_FAILURE);
	if (!d->t_pl || !d->t_wa || !d->t_en)
		exit (EXIT_FAILURE);
	d->i_co = mlx_texture_to_image(d->mlx, d->t_co);
	d->i_es = mlx_texture_to_image(d->mlx, d->t_es);
	d->i_c_ex = mlx_texture_to_image(d->mlx, d->t_c_ex);
	d->i_o_ex = mlx_texture_to_image(d->mlx, d->t_o_ex);
	d->i_pl = mlx_texture_to_image(d->mlx, d->t_pl);
	d->i_wa = mlx_texture_to_image(d->mlx, d->t_wa);
	d->i_en = mlx_texture_to_image(d->mlx, d->t_en);
	if (!d->i_co || !d->i_es || !d->i_c_ex)
		exit (EXIT_FAILURE);
	if (!d->i_pl || !d->i_wa || !d->i_en)
		exit (EXIT_FAILURE);
}

void	ft_delete_counter(t_all *d)
{
	mlx_delete_image(d->mlx, d->i_n0);
	mlx_delete_image(d->mlx, d->i_n1);
	mlx_delete_image(d->mlx, d->i_n2);
	mlx_delete_image(d->mlx, d->i_n3);
	mlx_delete_image(d->mlx, d->i_n4);
	mlx_delete_image(d->mlx, d->i_n5);
	mlx_delete_image(d->mlx, d->i_n6);
	mlx_delete_image(d->mlx, d->i_n7);
	mlx_delete_image(d->mlx, d->i_n8);
	mlx_delete_image(d->mlx, d->i_n9);
	mlx_delete_texture(d->t_n0);
	mlx_delete_texture(d->t_n1);
	mlx_delete_texture(d->t_n2);
	mlx_delete_texture(d->t_n3);
	mlx_delete_texture(d->t_n4);
	mlx_delete_texture(d->t_n5);
	mlx_delete_texture(d->t_n6);
	mlx_delete_texture(d->t_n7);
	mlx_delete_texture(d->t_n8);
	mlx_delete_texture(d->t_n9);
}

void	ft_delete_all(t_all *d)
{
	mlx_delete_image(d->mlx, d->i_co);
	mlx_delete_image(d->mlx, d->i_es);
	mlx_delete_image(d->mlx, d->i_c_ex);
	mlx_delete_image(d->mlx, d->i_o_ex);
	mlx_delete_image(d->mlx, d->i_pl);
	mlx_delete_image(d->mlx, d->i_wa);
	mlx_delete_image(d->mlx, d->i_en);
	mlx_delete_texture(d->t_co);
	mlx_delete_texture(d->t_es);
	mlx_delete_texture(d->t_c_ex);
	mlx_delete_texture(d->t_pl);
	mlx_delete_texture(d->t_wa);
	mlx_delete_texture(d->t_en);
	mlx_terminate(d->mlx);
	ft_delete_counter(d);
}
