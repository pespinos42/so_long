/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   graf_graf_bonus.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/20 16:26:13 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/11 10:33:13 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

void	ft_action_mlx_release(t_all *d)
{
	ft_op_positions(d);
	ft_check_other_position(d);
	ft_draw_map(d);
	ft_counter(d);
	ft_count_positions(d, &d->n_c, 'C');
	if (d->n_c == 0 && ft_check_finish(d))
	{
		ft_printf("HAS GANADO\n");
		mlx_close_window(d->mlx);
	}
	if (ft_check_enemy(d))
	{
		ft_printf("HAS MUERTO\n");
		mlx_close_window(d->mlx);
	}
}

void	ft_keys(mlx_key_data_t key, void *param)
{
	t_all	*d;

	d = param;
	if (key.action == MLX_PRESS)
		ft_player_position(d);
	if (key.key == MLX_KEY_ESCAPE && key.action == MLX_RELEASE)
		mlx_close_window(d->mlx);
	else if (key.key == MLX_KEY_W && key.action == MLX_RELEASE)
		d->move = 'W';
	else if (key.key == MLX_KEY_S && key.action == MLX_RELEASE)
		d->move = 'S';
	else if (key.key == MLX_KEY_A && key.action == MLX_RELEASE)
		d->move = 'A';
	else if (key.key == MLX_KEY_D && key.action == MLX_RELEASE)
		d->move = 'D';
	if (key.action == MLX_RELEASE)
		ft_action_mlx_release(d);
}

void	ft_initialize_data(t_all *d)
{
	int	fd;

	fd = 0;
	d->n_c = 0;
	d->n_e = 0;
	d->n_p = 0;
	d->p_r = 0;
	d->p_c = 0;
	d->o_r = 0;
	d->o_c = 0;
	d->move = 0;
	fd = open("mapa1.ber", O_RDONLY);
	d->rs = ft_number_rows(fd);
	fd = open("mapa1.ber", O_RDONLY);
	d->cs = ft_number_columns(fd);
	d->w = d->cs * 32;
	d->h = (d->rs + 1) * 32;
	fd = open("mapa1.ber", O_RDONLY);
	d->con = ft_create_content(fd, d->rs);
	d->exs = ft_configure_exits(d);
	d->ens = ft_configure_enemies(d);
	d->t_m = 0;
}

void	ft_main_conditions(t_all *d)
{
	d->mlx = mlx_init(d->w, d->h, "V1", false);
	if (!d->mlx)
		exit(EXIT_FAILURE);
	ft_initialize_textures(d);
	ft_initialize_counter1(d);
	ft_draw_map(d);
	ft_counter(d);
	mlx_key_hook(d->mlx, &ft_keys, d);
	mlx_loop(d->mlx);
	ft_delete_all(d);
}

int	main(int argc, char **argv)
{
	t_all			d;

	if (argc == 2 && ft_strnstr(argv[1], ".ber", ft_strlen(argv[1])))
	{
		ft_initialize_data(&d);
		if (d.rs < d.cs)
		{
			if (ft_control_char(&d) && ft_check_walls(d))
			{
				// d.mlx = mlx_init(d.w, d.h, "V1", false);
				// if (!d.mlx)
				// 	exit(EXIT_FAILURE);
				// ft_initialize_textures(&d);
				// ft_initialize_counter1(&d);
				// ft_draw_map(&d);
				// ft_counter(&d);
				// mlx_key_hook(d.mlx, &ft_keys, &d);
				// mlx_loop(d.mlx);
				// ft_delete_all(&d);
				ft_main_conditions(&d);
			}			
		}
		else
			ft_printf("ERROR\nNO ES RECTANGULAR\n");
	}
	else
		ft_printf("ERROR\nNUMERO DE PARAMETROS O ARCHIVO ERRONEO\n");
	return (EXIT_SUCCESS);
}
