/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long_bonus.h                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/21 13:08:41 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/10 13:01:53 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_BONUS_H
# define SO_LONG_BONUS_H
# ifndef BUFFER_SIZE
#  define BUFFER_SIZE 10
# endif
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include "MLX42/include/MLX42/MLX42.h"
# include <stdarg.h>
# include <limits.h>

typedef struct s_row_column
{
	int	r;
	int	c;
}	t_row_column;

typedef struct s_point_exit
{
	int	e_r;
	int	e_c;
	int	c_e;
}	t_point_exit;

typedef struct s_point_enemy
{
	int	e_r;
	int	e_c;
	int	c_e;
}	t_point_enemy;

typedef struct s_all
{
	mlx_texture_t	*t_co;
	mlx_texture_t	*t_es;
	mlx_texture_t	*t_o_ex;
	mlx_texture_t	*t_c_ex;
	mlx_texture_t	*t_pl;
	mlx_texture_t	*t_wa;
	mlx_texture_t	*t_en;
	mlx_image_t		*i_co;
	mlx_image_t		*i_es;
	mlx_image_t		*i_o_ex;
	mlx_image_t		*i_c_ex;
	mlx_image_t		*i_pl;
	mlx_image_t		*i_wa;
	mlx_image_t		*i_en;
	int				n_c;
	int				n_e;
	int				n_p;
	int				n_o;
	int				p_r;
	int				p_c;
	int				o_r;
	int				o_c;
	char			move;
	mlx_t			*mlx;
	int				w;
	int				h;
	int				rs;
	int				cs;
	char			**con;
	t_point_exit	*exs;
	t_point_enemy	*ens;
	int				t_m;
	mlx_texture_t	*t_n0;
	mlx_texture_t	*t_n1;
	mlx_texture_t	*t_n2;
	mlx_texture_t	*t_n3;
	mlx_texture_t	*t_n4;
	mlx_texture_t	*t_n5;
	mlx_texture_t	*t_n6;
	mlx_texture_t	*t_n7;
	mlx_texture_t	*t_n8;
	mlx_texture_t	*t_n9;
	mlx_image_t		*i_n0;
	mlx_image_t		*i_n1;
	mlx_image_t		*i_n2;
	mlx_image_t		*i_n3;
	mlx_image_t		*i_n4;
	mlx_image_t		*i_n5;
	mlx_image_t		*i_n6;
	mlx_image_t		*i_n7;
	mlx_image_t		*i_n8;
	mlx_image_t		*i_n9;
}	t_all;

//GET_NEXT_LINE_UTILS
char			*ft_strjoin(char const *s1, char const *s2);
char			*ft_substr(char const *s, unsigned int start, size_t len);
char			*ft_strchr(const char *s, int c);
size_t			ft_strlen(const char *s);
int				ft_strlen_n(const char *str);

//GET_NEXT_LINE
char			*ft_get_next_line(int fd);

//CHECK
char			*ft_strnstr(const char *b, const char *l, size_t len);
void			ft_conditions_columns(int *c1, int *cn, int *control, char *str);
int				ft_number_columns(int fd);
void			ft_conditions_walls(int r, int c, int *walls_ok, t_all data);
int				ft_check_walls(t_all data);
int				ft_number_rows(int fd);
char			**ft_create_content(int fd, int rows);
void			ft_control_char_conditions(t_all *data, int row, int column);
void			ft_control_char_count(t_all *data);
int				ft_control_char(t_all *data);

//GRAFICOS BONUS
void			ft_initialize_counter2(t_all *d);
void			ft_initialize_counter1(t_all *d);
void			ft_initialize_textures(t_all *d);
void			ft_delete_counter(t_all *d);
void			ft_delete_all(t_all *d);
void			ft_draw_exits(t_all *d, int r, int c);
void			ft_draw_map_conditions(t_all *d, int r, int c);
void			ft_draw_map(t_all *d);
void			ft_initial_counter(t_all *d);
void			ft_check_counter(t_all *d, char *counter, int i, int p);
void			ft_counter(t_all *d);
void			ft_op_positions(t_all *d);

//ITOA
char			*ft_strdup(char *src);
char			*ft_itoa(int n);

//KERNEL
int				ft_check_enemy(t_all *d);
int				ft_check_finish(t_all *d);
void			ft_count_positions(t_all *d, int *c_p, char l);
void			ft_loop_row_exits(t_all *d, t_row_column rc, t_point_exit *e, int *n_e);
t_point_exit	*ft_configure_exits(t_all *d);
void			ft_loop_row_ene(t_all *d, t_row_column rc, t_point_enemy *e, int *n_e);
t_point_enemy	*ft_configure_enemies(t_all *d);
void			ft_player_position(t_all *d);
int				ft_check_prev_position(t_point_exit *exits, int row, int column);
void			ft_op_conditions(t_all *d, int *ok_d);
int				ft_check_other_position(t_all *d);

//FT_PRINTF
void			ft_control(char option, va_list args, int *count);
int				ft_printf(char const *str, ...);
void			ft_print_hexa(unsigned long long int n, int ca, int *count, int loop);
void			ft_print_pointer(unsigned long long int n, int *count);
void			ft_printunsigned(long int n, int *count);
void			ft_printnbr(int n, int *count);
void			ft_print_char(char c, int *count);
void			ft_print_str(char *str, int *count);
int				ft_num_len(int n);

#endif