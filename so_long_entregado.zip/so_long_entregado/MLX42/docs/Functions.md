<!----------------------------------------------------------------------------
Copyright @ 2021-2022 Codam Coding College. All rights reserved.
See copyright and license notice in the root project for more information.
----------------------------------------------------------------------------->

# Functions

A list of all functions can be found here: [Functions](https://bit.ly/3aWZL7C)