/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   itoa.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/26 11:46:56 by pespinos          #+#    #+#             */
/*   Updated: 2023/01/10 19:34:09 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long_bonus.h"

typedef struct s_itoa_data
{
	int		sign;
	int		len;
	char	*result;
}	t_itoa_data;

char	*ft_strdup(char *src)
{
	char	*str;
	int		p;

	p = 0;
	str = malloc ((ft_strlen(src) + 1) * sizeof (*str));
	if (!str)
		return (NULL);
	while (src[p])
	{
		str[p] = src[p];
		p++;
	}
	str[p] = '\0';
	return (str);
}

static int	ft_len(int n)
{
	int	len;

	len = 0;
	while (n > 0)
	{
		len++;
		n /= 10;
	}
	return (len);
}

void	ft_itoa_conditions(int n, t_itoa_data *d)
{
	if (d->sign)
		d->result[0] = '-';
	d->result[d->len] = '\0';
	d->len--;
	while (n > 0)
	{
		d->result[d->len--] = (n % 10) + 48;
		n /= 10;
	}
}

char	*ft_itoa(int n)
{
	t_itoa_data	d;

	d.sign = 0;
	d.len = 0;
	if (n == 0)
		return (ft_strdup("0"));
	if (n < 0)
	{
		if (n == -2147483648)
			return (ft_strdup("-2147483648"));
		d.sign++;
		n = -n;
	}
	d.len = ft_len(n) + d.sign;
	d.result = malloc ((d.len + 1) * sizeof (*d.result));
	if (!d.result)
		return (NULL);
	ft_itoa_conditions(n, &d);
	return (d.result);
}
